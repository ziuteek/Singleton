# Wzorzec Singleton

Przykład ilustrujący budowę i wykorzystanie wzorca **Singleton**.

Przy okazji:
- korzystanie z testów jednostkowych
- zastosowanie formatu YAML (z biblioteką [snakeyaml](https://github.com/snakeyaml/snakeyaml))
- odczyt i zapis plików (`FileReader` i `FileWriter`)
- rzut oka na "generyki"
- kilka słów o wyjątkach
- elementarne wykorzystanie wątków (`Thread`)
