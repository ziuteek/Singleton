package edu.io;

public class AppConfig {

}
